import "./App.css";
import Recipes from "./Components/Recipes";

function App() {
  return (
    <div className="App">
      <Recipes />
    </div>
  );
}

export default App;
